CollegeBowlingNation
====================

Web application for collegebowlingnation.com

## Setup

Clone the repository, run `npm install` to get the node dependices.

### Running the app

In the app directory run:

    node app.js
