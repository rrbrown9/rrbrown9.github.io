(function(angular) {
	'use strict';
	angular.module('app.filters', ['app.filter.rollDisplay', 'app.filter.frameScore']);
}(angular));