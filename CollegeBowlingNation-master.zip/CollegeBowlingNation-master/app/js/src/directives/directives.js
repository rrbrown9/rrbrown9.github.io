(function(angular) {
	'use strict';
	angular.module('app.directives', ['app.directive.scoreCard','app.directive.scoreCardBaker','app.directive.replies','app.directive.bars']);
}(angular));
